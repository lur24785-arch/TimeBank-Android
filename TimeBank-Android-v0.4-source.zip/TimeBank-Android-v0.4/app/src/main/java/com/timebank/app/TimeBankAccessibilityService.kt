package com.timebank.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.PowerManager
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityWindowInfo
import androidx.core.content.ContextCompat

/** Resolve focused/active windows, not arbitrary event.packageName (IME/toast/system noise). */
class TimeBankAccessibilityService : AccessibilityService(), ForegroundProbe {
    private var registered = false
    private var connected = false
    private var windowSummary = "—"
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())
    private var retry: Runnable? = null
    private var lastStart = -30_000L
    private val engine get() = bankEngine
    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                Intent.ACTION_SCREEN_OFF -> engine.observe(null, "screen-off", "SCREEN", false)
                Intent.ACTION_TIME_CHANGED, Intent.ACTION_TIMEZONE_CHANGED ->
                    engine.refresh("CLOCK broadcast", discard = true)
                else -> engine.refresh("SCREEN / permission ${intent.action}")
            }
        }
    }
    override fun onServiceConnected() {
        super.onServiceConnected()
        connected = true
        serviceInfo = serviceInfo.apply {
            eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or
                AccessibilityEvent.TYPE_WINDOWS_CHANGED or AccessibilityEvent.TYPE_VIEW_FOCUSED
            flags = flags or AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
            notificationTimeout = 0
        }
        if (!registered) {
            val filter = IntentFilter().apply {
                addAction(Intent.ACTION_SCREEN_OFF); addAction(Intent.ACTION_SCREEN_ON)
                addAction(Intent.ACTION_USER_PRESENT); addAction(Intent.ACTION_TIME_CHANGED)
                addAction(Intent.ACTION_TIMEZONE_CHANGED)
                if (android.os.Build.VERSION.SDK_INT >= 31) {
                    addAction(android.app.AlarmManager.ACTION_SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED)
                }
            }
            ContextCompat.registerReceiver(this, screenReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
            registered = true
        }
        engine.attach(this)
        ensureMonitor()
    }
    private fun ensureMonitor() {
        val now = SystemClock.elapsedRealtime()
        if (!engine.ui.value.monitoring && now - lastStart >= 30_000) {
            lastStart = now
            MonitoringService.start(this)
        }
    }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!connected || event == null) return
        ensureMonitor()
        val raw = event.packageName?.toString() ?: "—"
        val resolved = foreground()
        engine.observe(resolved, raw, AccessibilityEvent.eventTypeToString(event.eventType),
            windows = windowSummary)
        if (resolved == null && retry == null) {
            // A single delayed re-probe handles roots not ready during a window transition.
            retry = Runnable {
                retry = null
                if (connected) engine.observe(foreground(), "re-probe", "WINDOW_RECHECK", false,
                    windows = windowSummary)
            }
            handler.postDelayed(retry!!, 150)
        } else if (resolved != null) {
            retry?.let { handler.removeCallbacks(it) }; retry = null
        }
    }
    override fun foreground(): String? {
        if (!connected) { windowSummary = "disconnected"; return null }
        if (!getSystemService(PowerManager::class.java).isInteractive ||
            getSystemService(KeyguardManager::class.java).isKeyguardLocked) {
            windowSummary = "screen-off / keyguard"; return null
        }
        return runCatching {
            val list = windows
            windowSummary = list.joinToString("; ") {
                "id=${it.id} type=${it.type} focused=${it.isFocused} active=${it.isActive}"
            }.ifEmpty { "no interactive windows; root fallback" }
            // The keyboard must not displace the application receiving text.
            val candidates = list.filter {
                (it.isActive || it.isFocused) && it.type != AccessibilityWindowInfo.TYPE_INPUT_METHOD &&
                    it.type != AccessibilityWindowInfo.TYPE_ACCESSIBILITY_OVERLAY
            }
            // A focused system panel (notification shade / recents) pauses accounting.
            val selected = candidates.firstOrNull { it.isActive }
                ?: candidates.firstOrNull { it.isFocused }
            if (selected != null) {
                if (selected.type != AccessibilityWindowInfo.TYPE_APPLICATION) return@runCatching null
                val root = selected.root ?: run { windowSummary += " root=null"; return@runCatching null }
                try { root.packageName?.toString()?.takeUnless { it == "com.android.systemui" } }
                finally { @Suppress("DEPRECATION") root.recycle() }
            } else {
                // Some OEMs expose only the active root. Never trust a naked event package.
                val root = rootInActiveWindow ?: return@runCatching null
                try {
                    val pkg = root.packageName?.toString()
                    val imePackages = getSystemService(android.view.inputmethod.InputMethodManager::class.java)
                        .inputMethodList.map { it.packageName }
                    pkg?.takeUnless { it == "com.android.systemui" || it in imePackages }
                } finally { @Suppress("DEPRECATION") root.recycle() }
            }
        }.onFailure { windowSummary = "probe error ${it.javaClass.simpleName}: ${it.message}" }.getOrNull()
    }
    override fun goHome(): Boolean = connected && performGlobalAction(GLOBAL_ACTION_HOME)
    override fun onInterrupt() { engine.note("ACCESS onInterrupt") }
    override fun onUnbind(intent: Intent?): Boolean {
        disconnect()
        return super.onUnbind(intent)
    }
    private fun disconnect() {
        connected = false
        retry?.let { handler.removeCallbacks(it) }; retry = null
        engine.detach(this)
        if (registered) { unregisterReceiver(screenReceiver); registered = false }
    }
    override fun onDestroy() { disconnect(); super.onDestroy() }
}
