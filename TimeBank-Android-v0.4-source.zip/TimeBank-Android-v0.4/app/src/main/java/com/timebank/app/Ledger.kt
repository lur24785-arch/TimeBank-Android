package com.timebank.app

import java.time.Instant
import java.time.ZoneId

enum class Role { IDLE, EARNING, SPENDING }
data class Bank(
    val day: String = "", val balanceMs: Long = 0, val earnedMs: Long = 0,
    val spentMs: Long = 0, val earn: Set<String> = emptySet(), val spend: Set<String> = emptySet()
)
data class Settlement(val bank: Bank, val deltaMs: Long, val reset: Boolean, val rejected: Boolean)

/** Pure interval arithmetic; running timestamps NEVER survive process death. */
object Ledger {
    fun day(wall: Long, zone: ZoneId): String =
        Instant.ofEpochMilli(wall).atZone(zone).toLocalDateTime().minusHours(4).toLocalDate().toString()
    fun dayStart(wall: Long, zone: ZoneId): Long =
        java.time.LocalDate.parse(day(wall, zone)).atTime(4, 0).atZone(zone).toInstant().toEpochMilli()
    fun nextDay(wall: Long, zone: ZoneId): Long =
        java.time.LocalDate.parse(day(wall, zone)).plusDays(1).atTime(4, 0)
            .atZone(zone).toInstant().toEpochMilli()

    fun settle(bank: Bank, role: Role, startMono: Long, startWall: Long,
               mono: Long, wall: Long, zone: ZoneId): Settlement {
        val today = day(wall, zone)
        val reset = bank.day != today
        var b = if (reset) bank.copy(day = today, balanceMs = 0, earnedMs = 0, spentMs = 0) else bank
        val duration = mono - startMono
        // A clock adjustment or implausible interval is not treated as usage.
        val rejected = duration < 0 || duration > 26 * 60 * 60 * 1000L ||
            kotlin.math.abs((wall - startWall) - duration) > 2000
        val eligible = if (rejected) 0L else minOf(duration, (wall - dayStart(wall, zone)).coerceAtLeast(0))
        val delta = when (role) {
            Role.EARNING -> eligible
            Role.SPENDING -> -minOf(eligible, b.balanceMs)
            Role.IDLE -> 0L
        }
        b = b.copy(balanceMs = b.balanceMs + delta,
            earnedMs = b.earnedMs + delta.coerceAtLeast(0),
            spentMs = b.spentMs + (-delta).coerceAtLeast(0))
        return Settlement(b, delta, reset, rejected)
    }
}
