package com.timebank.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class DeadlineReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val pending = goAsync()
        val finished = java.util.concurrent.atomic.AtomicBoolean(false)
        val handler = android.os.Handler(android.os.Looper.getMainLooper())
        val finish = Runnable { if (finished.compareAndSet(false, true)) pending.finish() }
        // Even a failed/unavailable DataStore must not leave a broadcast pending indefinitely.
        handler.postDelayed(finish, 8000)
        context.bankEngine.deadline(intent.getLongExtra("token", -1)) {
            handler.removeCallbacks(finish)
            finish.run()
        }
    }
}
