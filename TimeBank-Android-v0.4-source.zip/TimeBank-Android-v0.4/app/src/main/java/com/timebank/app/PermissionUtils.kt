package com.timebank.app

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.net.Uri

fun isTimeBankAccessibilityEnabled(context: Context): Boolean {
    val expected = ComponentName(context, TimeBankAccessibilityService::class.java)
    return Settings.Secure.getString(context.contentResolver,
        Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)?.split(':')?.any {
        ComponentName.unflattenFromString(it) == expected
    } == true
}
fun openAccessibilitySettings(context: Context) {
    context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}
fun openExactAlarmSettings(context: Context) {
    if (Build.VERSION.SDK_INT >= 31) {
        runCatching {
            context.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                Uri.parse("package:${context.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }.onFailure { context.bankEngine.note("Cannot open exact alarm settings: ${it.message}") }
    }
}
