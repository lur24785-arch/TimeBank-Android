package com.timebank.app

import android.app.Application
import android.content.Context

class TimeBankApplication : Application() {
    val engine by lazy { BankEngine(this) }
}
val Context.bankEngine: BankEngine
    get() = (applicationContext as TimeBankApplication).engine
