package com.timebank.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat

/** Keeps process importance explicit. No polling or independent accounting writer here. */
class MonitoringService : Service() {
    companion object {
        fun start(context: Context) {
            try { ContextCompat.startForegroundService(context, Intent(context, MonitoringService::class.java)) }
            catch (e: RuntimeException) {
                context.bankEngine.monitoring(false, "MONITOR start failed ${e.javaClass.simpleName}: ${e.message}")
            }
        }
    }
    override fun onCreate() {
        super.onCreate()
        val channel = "timebank_monitoring"
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(channel, getString(R.string.notification_channel_name), NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = NotificationCompat.Builder(this, channel)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle(getString(R.string.notification_title))
            .setContentText(getString(R.string.notification_text))
            .setContentIntent(open).setOngoing(true).setOnlyAlertOnce(true).build()
        try {
            ServiceCompat.startForeground(this, 2001, notification,
                if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0)
            bankEngine.monitoring(true)
        } catch (e: RuntimeException) {
            bankEngine.monitoring(false, "MONITOR foreground failed ${e.message}")
            stopSelf()
        }
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        bankEngine.refresh("MONITOR start")
        return START_STICKY
    }
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onDestroy() { bankEngine.monitoring(false); super.onDestroy() }
}
