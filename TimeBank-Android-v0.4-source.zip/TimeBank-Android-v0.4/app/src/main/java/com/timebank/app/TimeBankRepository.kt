package com.timebank.app

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first

private val Context.timeBankDataStore by preferencesDataStore(name = "timebank_settings")

/** One writer: BankEngine's serial mailbox. Preserve v0.3 keys and selections. */
class TimeBankRepository(private val context: Context) {
    private val earn = stringSetPreferencesKey("earn_apps")
    private val spend = stringSetPreferencesKey("spend_apps")
    private val day = stringPreferencesKey("active_day")
    private fun ms(name: String) = longPreferencesKey(name + "_ms")
    private fun seconds(name: String) = longPreferencesKey(name + "_seconds")
    suspend fun read(): Bank {
        val p = context.timeBankDataStore.data.first()
        fun amount(name: String): Long = (p[ms(name)] ?: ((p[seconds(name)] ?: 0L)
            .coerceIn(0, Long.MAX_VALUE / 1000) * 1000)).coerceAtLeast(0)
        val e = (p[earn] ?: emptySet()) - context.packageName
        return Bank(p[day] ?: "", amount("balance"), amount("earned"), amount("spent"),
            e, (p[spend] ?: emptySet()) - e - context.packageName)
    }
    suspend fun save(bank: Bank) {
        context.timeBankDataStore.edit { p ->
            p[day] = bank.day; p[earn] = bank.earn; p[spend] = bank.spend
            listOf("balance" to bank.balanceMs, "earned" to bank.earnedMs,
                "spent" to bank.spentMs).forEach { (name, value) ->
                p[ms(name)] = value; p[seconds(name)] = value / 1000
            }
        }
    }
}
