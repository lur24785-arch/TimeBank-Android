package com.timebank.app

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

class MainActivity : ComponentActivity() {
    private val permission = mutableStateOf(false)
    private val exact = mutableStateOf(false)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this,
                Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 3001)
        }
        setContent { MaterialTheme { TimeBankApp(permission.value, exact.value) } }
    }
    override fun onResume() {
        super.onResume()
        permission.value = isTimeBankAccessibilityEnabled(this)
        exact.value = bankEngine.exactAllowed()
        MonitoringService.start(this)
        bankEngine.refresh("UI resume")
    }
}

@Composable
private fun TimeBankApp(accessEnabled: Boolean, exactAllowed: Boolean) {
    val context = LocalContext.current
    val engine = remember { context.bankEngine }
    val state by engine.ui.collectAsState()
    var apps by remember { mutableStateOf<List<InstalledApp>>(emptyList()) }
    var query by remember { mutableStateOf("") }
    var expanded by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { apps = loadLaunchableApps(context) }
    val filtered = remember(apps, query) { apps.filter {
        it.name.contains(query, true) || it.packageName.contains(query, true)
    } }
    Surface(Modifier.fillMaxSize()) {
        LazyColumn(Modifier.fillMaxSize().safeDrawingPadding().padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                Text("时间银行 v0.4.0", style = MaterialTheme.typography.headlineMedium)
                Text("学习 : 娱乐 = 1 : 1 · 每天 04:00 清零")
                Text("单一焦点窗口计时；分屏只计当前操作的应用。")
            }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("娱乐余额：${duration(state.bank.balanceMs)}", style = MaterialTheme.typography.headlineSmall)
                        Text("今日赚取：${duration(state.bank.earnedMs)}")
                        Text("今日消费：${duration(state.bank.spentMs)}")
                        Text("返回本页时结算；运行期间按完整区间记账。")
                        Text("无障碍设置：${if (accessEnabled) "已开启" else "未开启"}；连接：${if (state.connected) "已连接" else "未连接"}")
                        Text("后台服务：${if (state.monitoring) "已启动" else "未运行"}")
                        Text("精确闹钟：${if (exactAllowed) "允许" else "未允许，耗尽拦截可能延迟"}")
                        Button(onClick = { openAccessibilitySettings(context) }) { Text("无障碍设置") }
                        if (!exactAllowed) Button(onClick = { openExactAlarmSettings(context) }) { Text("允许精确耗尽提醒") }
                        Button(onClick = { MonitoringService.start(context); engine.refresh("USER refresh") }) {
                            Text("启动服务 / 刷新诊断")
                        }
                        Text("HyperOS：若仍被限制，请在应用设置允许后台自启动、将省电策略设为无限制。设置已开但未连接时，关闭再开启无障碍。")
                        TextButton(onClick = { engine.reset() }, enabled = state.ready) { Text("清零余额和今日统计") }
                    }
                }
            }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text("诊断", style = MaterialTheme.typography.titleMedium)
                        Text("最近事件包：${state.rawPackage}")
                        Text("最近事件：${time(state.eventAt)}")
                        Text("计时包：${state.current ?: "无"}")
                        Text("状态：${state.state}；后台服务：${state.monitoring}")
                        Text("最近记账：${time(state.bookedAt)} / ${state.deltaMs / 1000.0} 秒")
                        Text("耗尽任务：${state.alarm}")
                        Text("窗口：${state.windows}", style = MaterialTheme.typography.bodySmall)
                        Button(onClick = {
                            context.getSystemService(ClipboardManager::class.java)
                                .setPrimaryClip(ClipData.newPlainText("TimeBank diagnostics", engine.diagnostics()))
                        }) { Text("复制诊断信息") }
                        TextButton(onClick = { expanded = !expanded }) { Text(if (expanded) "收起日志" else "展开最近 50 条日志") }
                        if (expanded) Text(state.log.joinToString("\n"), style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            item {
                OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), label = { Text("搜索已安装应用") }, singleLine = true)
                Text("应用名称                             学习 / 娱乐")
            }
            items(filtered, key = { it.packageName }) { app ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(app.name)
                        Text(app.packageName, style = MaterialTheme.typography.bodySmall)
                    }
                    Checkbox(app.packageName in state.bank.earn,
                        { engine.select(app.packageName, true, it) }, enabled = state.ready)
                    Checkbox(app.packageName in state.bank.spend,
                        { engine.select(app.packageName, false, it) }, enabled = state.ready)
                }
                HorizontalDivider()
            }
        }
    }
}
private fun duration(ms: Long): String {
    val seconds = ms.coerceAtLeast(0) / 1000
    return "${seconds / 3600} 时 ${(seconds % 3600) / 60} 分 ${seconds % 60} 秒"
}
private fun time(wall: Long): String = if (wall == 0L) "—" else
    DateTimeFormatter.ofPattern("MM-dd HH:mm:ss").withZone(ZoneId.systemDefault()).format(Instant.ofEpochMilli(wall))
