package com.timebank.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.time.ZoneId
import java.time.Instant
import java.time.format.DateTimeFormatter

interface ForegroundProbe {
    fun foreground(): String?
    fun goHome(): Boolean
}
data class BankUi(
    val bank: Bank = Bank(), val ready: Boolean = false,
    val connected: Boolean = false, val monitoring: Boolean = false,
    val rawPackage: String = "—", val eventAt: Long = 0, val current: String? = null,
    val state: String = "idle", val bookedAt: Long = 0, val deltaMs: Long = 0,
    val alarm: String = "none", val windows: String = "—", val log: List<String> = emptyList()
)

/** Application-scoped serial actor. Services submit observations, never share a stale static package. */
class BankEngine(private val context: Context) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val commands = Channel<suspend () -> Unit>(Channel.UNLIMITED)
    private val repo = TimeBankRepository(context)
    private val history = context.getSharedPreferences("diagnostics_v4", Context.MODE_PRIVATE)
    private val mutable = MutableStateFlow(BankUi(log = history.getString("log", "")!!
        .lines().filter { it.isNotBlank() }.takeLast(50)))
    val ui = mutable.asStateFlow()
    private var bank = Bank()
    private var probe: ForegroundProbe? = null
    private var current: String? = null
    private var role = Role.IDLE
    private var mono = SystemClock.elapsedRealtime()
    private var wall = System.currentTimeMillis()
    private var zone = ZoneId.systemDefault()
    private val handler = Handler(Looper.getMainLooper())
    private val alarms = context.getSystemService(AlarmManager::class.java)
    private var alarmIntent: PendingIntent? = null
    private var timer: Runnable? = null
    private var token = System.nanoTime()
    private var lastHome = -10000L
    private var lastToast = -10000L
    private var checkpoint: Runnable? = null

    init {
        scope.launch {
            try {
                bank = repo.read()
                val now = System.currentTimeMillis()
                bank = Ledger.settle(bank, Role.IDLE, mono, wall,
                    SystemClock.elapsedRealtime(), now, zone).bank
                repo.save(bank)
                mono = SystemClock.elapsedRealtime(); wall = System.currentTimeMillis()
                mutable.value = mutable.value.copy(bank = bank, ready = true)
                log("PROCESS start: no old interval restored")
            } catch (e: Exception) { log("INIT ERROR ${e.javaClass.simpleName}: ${e.message}") }
            for (command in commands) {
                try {
                    if (mutable.value.ready) command() else log("COMMAND skipped: storage initialization failed")
                } catch (e: Exception) {
                    current = null; role = Role.IDLE; cancelDeadline()
                    log("ERROR ${e.javaClass.simpleName}: ${e.message}")
                    publish()
                }
            }
        }
    }
    private fun submit(block: suspend () -> Unit) { commands.trySend(block) }
    private fun log(message: String) {
        val time = DateTimeFormatter.ofPattern("HH:mm:ss.SSS").withZone(ZoneId.systemDefault())
            .format(Instant.now())
        val logs = (mutable.value.log + "$time $message").takeLast(50)
        mutable.value = mutable.value.copy(log = logs)
        history.edit().putString("log", logs.joinToString("\n")).apply()
    }
    private fun publish() {
        val state = when {
            role == Role.SPENDING && bank.balanceMs == 0L -> "blocked"
            role == Role.SPENDING -> "spending"
            role == Role.EARNING -> "earning"
            else -> "idle"
        }
        mutable.value = mutable.value.copy(bank = bank, current = current, state = state)
    }
    private suspend fun settle(atMono: Long, atWall: Long) {
        // Observations captured on the main thread preserve their order through async disk writes.
        val result = Ledger.settle(bank, role, mono, wall, atMono, atWall, zone)
        bank = result.bank
        mono = atMono; wall = atWall
        repo.save(bank)
        if (result.reset) log("DAY reset ${bank.day}")
        if (result.rejected) log("INTERVAL discarded: clock jump / stale interval")
        if (result.deltaMs != 0L) {
            mutable.value = mutable.value.copy(bookedAt = atWall, deltaMs = result.deltaMs)
            log("BOOK ${result.deltaMs / 1000.0} sec $current")
        }
    }
    private fun classify(pkg: String?): Role = when {
        pkg == null || pkg == context.packageName -> Role.IDLE
        pkg in bank.earn -> Role.EARNING
        pkg in bank.spend -> Role.SPENDING
        else -> Role.IDLE
    }
    fun attach(value: ForegroundProbe) = submit {
        settle(SystemClock.elapsedRealtime(), System.currentTimeMillis())
        probe = value
        mutable.value = mutable.value.copy(connected = true)
        current = value.foreground(); role = classify(current)
        log("ACCESS connected; probe=$current")
        finishTransition()
    }
    fun detach(value: ForegroundProbe) {
        val m = SystemClock.elapsedRealtime(); val w = System.currentTimeMillis()
        submit {
            if (probe === value) {
                settle(m, w); probe = null; current = null; role = Role.IDLE
                mutable.value = mutable.value.copy(connected = false)
                log("ACCESS disconnected")
                finishTransition()
            }
        }
    }
    fun observe(pkg: String?, raw: String, kind: String, event: Boolean = true, windows: String? = null) {
        val m = SystemClock.elapsedRealtime(); val w = System.currentTimeMillis()
        submit {
            if (windows != null) mutable.value = mutable.value.copy(windows = windows)
            if (event) mutable.value = mutable.value.copy(rawPackage = raw, eventAt = w)
            // Repeated events are evidence, not a reason to keep moving the deadline.
            if (pkg == current && Ledger.day(w, ZoneId.systemDefault()) == bank.day) {
                if (role == Role.SPENDING && bank.balanceMs == 0L) enforce()
                return@submit
            }
            settle(m, w)
            zone = ZoneId.systemDefault()
            current = pkg; role = classify(pkg)
            log("$kind raw=$raw resolved=$pkg")
            finishTransition()
        }
    }
    private fun guardMissedScreenOff() {
        val interactive = context.getSystemService(android.os.PowerManager::class.java).isInteractive
        val locked = context.getSystemService(android.app.KeyguardManager::class.java).isKeyguardLocked
        if ((!interactive || locked) && role != Role.IDLE) {
            role = Role.IDLE
            log("SCREEN gap: missing off event; discard uncertain interval")
        }
    }
    fun refresh(reason: String = "REFRESH", discard: Boolean = false) {
        val m = SystemClock.elapsedRealtime(); val w = System.currentTimeMillis()
        submit {
            guardMissedScreenOff()
            if (discard) { role = Role.IDLE; log("CLOCK change: discard open interval") }
            settle(m, w); zone = ZoneId.systemDefault()
            // Re-run under the new zone after timezone changes.
            settle(m, w)
            current = probe?.foreground(); role = classify(current)
            log(reason)
            finishTransition()
        }
    }
    fun monitoring(running: Boolean, error: String? = null) = submit {
        mutable.value = mutable.value.copy(monitoring = running)
        log(error ?: "MONITOR running=$running")
    }
    fun note(message: String) = submit { log(message) }
    fun reset() = submit {
        settle(SystemClock.elapsedRealtime(), System.currentTimeMillis())
        bank = bank.copy(balanceMs = 0, earnedMs = 0, spentMs = 0)
        repo.save(bank); log("MANUAL reset")
        finishTransition()
    }
    fun select(pkg: String, learning: Boolean, checked: Boolean) = submit {
        if (pkg == context.packageName) return@submit
        settle(SystemClock.elapsedRealtime(), System.currentTimeMillis())
        bank = if (learning) bank.copy(earn = if (checked) bank.earn + pkg else bank.earn - pkg,
            spend = if (checked) bank.spend - pkg else bank.spend)
        else bank.copy(spend = if (checked) bank.spend + pkg else bank.spend - pkg,
            earn = if (checked) bank.earn - pkg else bank.earn)
        repo.save(bank); role = classify(current)
        log("ROLE $pkg learning=$learning checked=$checked")
        finishTransition()
    }
    private fun finishTransition() {
        enforce(); scheduleDeadline(); scheduleCheckpoint(); publish()
    }
    private fun enforce() {
        if (role != Role.SPENDING || bank.balanceMs > 0 || current == context.packageName) return
        val now = SystemClock.elapsedRealtime()
        // Re-read live windows; never HOME a different app because of a queued observation.
        if (probe?.foreground() != current || now - lastHome < 900) return
        lastHome = now
        val ok = probe?.goHome() == true
        log("BALANCE exhausted -> HOME result=$ok package=$current")
        if (now - lastToast >= 4000) {
            lastToast = now
            android.widget.Toast.makeText(context, "娱乐余额为 0，先去学习赚时间",
                android.widget.Toast.LENGTH_SHORT).show()
        }
    }
    private fun cancelDeadline() {
        token++
        timer?.let { handler.removeCallbacks(it) }; timer = null
        alarmIntent?.let { alarms.cancel(it) }; alarmIntent = null
        mutable.value = mutable.value.copy(alarm = "none")
    }
    fun exactAllowed(): Boolean = Build.VERSION.SDK_INT < 31 || alarms.canScheduleExactAlarms()
    private fun scheduleDeadline() {
        cancelDeadline()
        if (role == Role.IDLE || probe == null) return
        if (role == Role.SPENDING && bank.balanceMs == 0L) {
            // Bounded-frequency retry also handles immediate re-entry during HOME debounce.
            val t = token
            timer = Runnable { deadline(t) }
            handler.postDelayed(timer!!, 1000)
            return
        }
        val untilDay = (Ledger.nextDay(wall, zone) - wall).coerceAtLeast(1)
        val delay = if (role == Role.SPENDING) minOf(bank.balanceMs, untilDay) else untilDay
        val due = mono + delay
        val t = token
        timer = Runnable { deadline(t) }
        handler.postDelayed(timer!!, (due - SystemClock.elapsedRealtime()).coerceAtLeast(1))
        val pi = PendingIntent.getBroadcast(context, 4,
            Intent(context, DeadlineReceiver::class.java).putExtra("token", t),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        alarmIntent = pi
        try {
            if (exactAllowed()) {
                // Screen-off cancels this. No allow-while-idle quota for repeated entertainment visits.
                alarms.setExact(AlarmManager.ELAPSED_REALTIME_WAKEUP, due, pi)
                mutable.value = mutable.value.copy(alarm = "exact + handler; in ${delay / 1000.0}s")
            } else {
                alarms.set(AlarmManager.ELAPSED_REALTIME_WAKEUP, due, pi)
                mutable.value = mutable.value.copy(alarm = "DEGRADED: 未允许精确闹钟")
            }
        } catch (e: SecurityException) {
            log("ALARM denied ${e.message}")
            mutable.value = mutable.value.copy(alarm = "DEGRADED: handler only")
        }
    }
    fun deadline(expected: Long, done: () -> Unit = {}) = submit {
        try {
            if (expected != token || probe == null) {
                log("ALARM stale / no accessibility connection")
                return@submit
            }
            guardMissedScreenOff()
            settle(SystemClock.elapsedRealtime(), System.currentTimeMillis())
            current = probe?.foreground(); role = classify(current)
            log("DEADLINE delivered")
            finishTransition()
        } finally { done() }
    }
    private fun scheduleCheckpoint() {
        checkpoint?.let { handler.removeCallbacks(it) }; checkpoint = null
        if (role == Role.IDLE) return
        // Best-effort crash-loss bound; correctness uses the entire interval if this fires late.
        checkpoint = Runnable { refresh("CHECKPOINT") }
        handler.postDelayed(checkpoint!!, 60_000)
    }
    fun diagnostics(): String = ui.value.let {
        "TimeBank 0.4.0 | ${Build.MANUFACTURER} ${Build.MODEL} SDK ${Build.VERSION.SDK_INT}\n" +
        "accessEnabled=${isTimeBankAccessibilityEnabled(context)} connected=${it.connected} monitoring=${it.monitoring}\n" +
        "raw=${it.rawPackage} eventAt=${it.eventAt} current=${it.current} state=${it.state}\n" +
        "windows=${it.windows}\n" +
        "day=${it.bank.day} balanceMs=${it.bank.balanceMs} earnedMs=${it.bank.earnedMs} spentMs=${it.bank.spentMs}\n" +
        "bookedAt=${it.bookedAt} deltaMs=${it.deltaMs} exactAllowed=${exactAllowed()} alarm=${it.alarm}\n" +
        "${it.log.joinToString("\n")}"
    }
}
