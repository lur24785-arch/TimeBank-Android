package com.timebank.app

import org.junit.Assert.*
import org.junit.Test
import java.time.ZoneId
import java.time.ZonedDateTime

class LedgerTest {
    private val zone = ZoneId.of("Asia/Shanghai")
    private fun at(s: String) = ZonedDateTime.parse(s + "+08:00[Asia/Shanghai]").toInstant().toEpochMilli()
    private val start = at("2026-09-21T12:00:00")
    private fun bank(balance: Long = 0) = Bank("2026-09-21", balance, earn = setOf("notes"), spend = setOf("video"))
    @Test fun delayedCallbackCreditsWhole129Seconds() {
        val r = Ledger.settle(bank(), Role.EARNING, 1000, start, 130000, start + 129000, zone)
        assertEquals(129000L, r.bank.balanceMs)
        assertEquals(129000L, r.bank.earnedMs)
    }
    @Test fun exact37SecondConsumption() {
        val r = Ledger.settle(bank(37000), Role.SPENDING, 1000, start, 38000, start + 37000, zone)
        assertEquals(0L, r.bank.balanceMs); assertEquals(37000L, r.bank.spentMs)
    }
    @Test fun lateDeadlineCannotProduceNegativeBalance() {
        val r = Ledger.settle(bank(37000), Role.SPENDING, 0, start, 120000, start + 120000, zone)
        assertEquals(0L, r.bank.balanceMs); assertEquals(37000L, r.bank.spentMs)
    }
    @Test fun idleAndScreenOffDoNotCount() {
        val r = Ledger.settle(bank(37000), Role.IDLE, 0, start, 600000, start + 600000, zone)
        assertEquals(37000L, r.bank.balanceMs); assertEquals(0L, r.deltaMs)
    }
    @Test fun dayBoundaryOnlyCreditsNewDayTail() {
        val w = at("2026-09-22T03:59:50")
        val r = Ledger.settle(bank(100000), Role.EARNING, 0, w, 30000, w + 30000, zone)
        assertEquals("2026-09-22", r.bank.day)
        assertEquals(20000L, r.bank.balanceMs)
        assertEquals(20000L, r.bank.earnedMs)
        assertEquals(setOf("notes"), r.bank.earn); assertEquals(setOf("video"), r.bank.spend)
    }
    @Test fun midnightDoesNotReset() {
        val w = at("2026-09-21T23:59:50")
        val r = Ledger.settle(bank(), Role.EARNING, 0, w, 30000, w + 30000, zone)
        assertFalse(r.reset); assertEquals(30000L, r.bank.balanceMs)
    }
    @Test fun dayBoundaryCancelsEntertainmentCredit() {
        val w = at("2026-09-22T03:59:50")
        val r = Ledger.settle(bank(900000), Role.SPENDING, 0, w, 30000, w + 30000, zone)
        assertEquals(0L, r.bank.balanceMs); assertEquals(0L, r.bank.spentMs)
    }
    @Test fun fractionalIntervalsAreNotLost() {
        val a = Ledger.settle(bank(), Role.EARNING, 0, start, 750, start + 750, zone)
        val b = Ledger.settle(a.bank, Role.EARNING, 750, start + 750, 1500, start + 1500, zone)
        assertEquals(1500L, b.bank.balanceMs)
    }
    @Test fun wallClockJumpIsDiscarded() {
        val r = Ledger.settle(bank(), Role.EARNING, 0, start, 1000, start + 3600000, zone)
        assertTrue(r.rejected); assertEquals(0L, r.deltaMs)
    }
    @Test fun oldOrRebootTimestampIsDiscarded() {
        assertTrue(Ledger.settle(bank(), Role.EARNING, 5000, start, 1000, start + 1000, zone).rejected)
        assertTrue(Ledger.settle(bank(), Role.EARNING, 0, start, 100000000, start + 100000000, zone).rejected)
    }
    @Test fun restartOnlyResetsDayNeverRestoresRunningInterval() {
        val r = Ledger.settle(bank(10000), Role.IDLE, 0, start, 0, start, zone)
        assertEquals(10000L, r.bank.balanceMs)
    }
    @Test fun boundaryCalculation() {
        val before = at("2026-09-22T03:59:59")
        assertEquals("2026-09-21", Ledger.day(before, zone))
        assertEquals(at("2026-09-22T04:00:00"), Ledger.nextDay(before, zone))
        assertEquals("2026-09-22", Ledger.day(before + 1000, zone))
    }
    @Test fun daylightSavingStillResetsAtLocalFour() {
        val ny = ZoneId.of("America/New_York")
        for (date in listOf("2026-03-08", "2026-11-01")) {
            val boundary = java.time.LocalDate.parse(date).atTime(4, 0).atZone(ny).toInstant().toEpochMilli()
            assertEquals(date, Ledger.day(boundary, ny))
            assertEquals(java.time.LocalDate.parse(date).minusDays(1).toString(), Ledger.day(boundary - 1, ny))
        }
    }
}
