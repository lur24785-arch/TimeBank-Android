# v0.4.0 构建验证

最终源码实际执行（2026-09-21）：

```
gradle --no-daemon :app:clean :app:testDebugUnitTest :app:assembleDebug :app:lintDebug
BUILD SUCCESSFUL in 1m 47s
53 actionable tasks: 53 executed
```

- Gradle 8.13，Temurin JDK 17，Android SDK 36，build-tools 36.0.0。
- 实际生成 `app/build/outputs/apk/debug/app-debug.apk`。
- 13 项账本单元测试全部通过，0 失败、0 错误。
- Lint：0 errors, 3 warnings。剩余为 1 条未显式指定应用图标提示和 2 条 AndroidX KTX 写法建议，不是编译或 API 兼容性错误。
- XML 可解析；工作流设置 `packages: platform-tools`，解压目录与 ZIP 根目录匹配。
- 未运行 Android 模拟器或 HyperOS 真机测试。单元测试验证区间数学，不验证 OEM 事件交付、精确闹钟实际延迟和 HOME 实机行为。
- 新版保留 DataStore 文件名及旧应用分类键，但覆盖安装仍需相同签名。

测试涵盖：129 秒延迟结算、37 秒消费、延迟耗尽余额不负、idle 不计时、跨 04:00 的学习与消费、午夜不重置、毫秒余量、手动时钟跳变、旧时间戳保护、重启不推断运行区间、日界线与夏令时。
