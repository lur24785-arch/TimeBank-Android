# TimeBank / 时间银行 0.4.0

包名 `com.timebank.app`；versionCode 4；minSdk 26；compile/targetSdk 36。
Kotlin + Compose + Preferences DataStore；Java 17 / Gradle 8.13 / build-tools 36.0.0。

## 本版针对什么问题

完整审阅了 v0.3 ZIP 中的 18 个文件。以下是源码确定存在的问题，不等于已通过实机日志证明唯一根因：

- `MonitoringService` 每秒循环，将一次延迟的记账限制在最多 3 秒；调度暂停后无法补回完整区间，整数秒截断也会丢小数。
- `accessibilityForegroundUpdatedAt` 写入却从未使用。任意 `event.packageName` 都覆盖前台包名；没有可验证的焦点窗口，也没有过期/失联状态。
- 只监听 `TYPE_WINDOW_STATE_CHANGED`，配置禁用窗口内容读取，并在连接时将 flags 设为 0，无法借助交互窗口识别输入法、系统面板及分屏焦点。
- `lastBlockedPackage` / `blockRequestedFor` 依靠看到别的包名才能解锁去重；若桌面事件漏掉，再次打开同一娱乐应用可能不再执行 HOME。HOME 返回值不记录。
- 首页启动服务仍以 Usage Access 为前置条件，和“可选 fallback”的说明矛盾。
- 没有可用诊断，不能从“通知还在”判断事件、计时协程、拦截链路分别是否工作。

## 新架构

`AccessibilityService → Application 内串行 BankEngine → DataStore`

- AccessibilityService 监听窗口状态、窗口集合和视图焦点变化，读取 active/focused 窗口的根包名。输入法不直接覆盖当前应用；系统面板、锁屏和熄屏进入 idle。不读取/保存页面文字。
- 不保存一个等待另一个服务轮询的 static 包名。所有事件、手动清零、分类修改、闹钟通过单一命令队列串行处理。持久化后才发布账本。
- 用 `elapsedRealtime()` 的完整时间差结算前一个状态区间。保留毫秒，显示为秒。自己、桌面和未分类应用不记账。分类互斥。
- 前台服务只维持进程优先级和通知，没有每秒计时循环。60 秒 checkpoint 仅减少进程崩溃时未保存的损失；若回调延迟，之后照样结算完整区间，不用回调次数算时间。
- 娱乐状态余额 > 0 时安排 `AlarmManager.setExact(ELAPSED_REALTIME_WAKEUP)` 一次性任务，期限取“余额耗尽”和“下一个 04:00”的较早者。Handler 一次性回调作同进程备份。切换/熄屏会取消并重建；token 拒绝旧任务。
- Android 12+ 申请 `SCHEDULE_EXACT_ALARM` 特殊访问，不使用自动授予且用途受限的 `USE_EXACT_ALARM`。未授权时首页显示降级；只能 Handler + 非精确闹钟，不能保证准时。
- 不用 allow-while-idle 避免其频率限制；熄屏本就不需要计时。系统强制冻结/停止应用仍可能延迟或阻止任务，不能宣称绕过 HyperOS。
- 耗尽后重新核验当前窗口，执行 `GLOBAL_ACTION_HOME`，记录返回值。不启动 BlockActivity。HOME 最快间隔 900ms，失败或仍在目标窗口时以 1 秒回调重试；Toast 最快间隔 4 秒。
- 04:00 logical day 持久化。所有结算检查日期，长区间跨日只保留新日尾段；学习期间也设一次日界线任务。进程不在 04:00 存活仍会在下次运行重置。
- 时长用单调时钟；本地日期只用于日界线。时区/手动时间变更保守丢弃未结算区间并重新锚定；跨度超过 26 小时或时钟不一致也丢弃并写日志。
- 进程重启从持久账本开始，但绝不恢复旧“正在运行”的时间戳，不推断进程死亡期间是否一直使用同一应用。最近未提交区间可能丢失；checkpoint 正常运行时通常不超过约 60 秒，OEM 冻结时可能更多。

## 首次安装/升级

1. 使用相同签名覆盖安装才能保留 Android 应用数据。DataStore 名称 `timebank_settings` 与 `earn_apps`、`spend_apps`、`active_day` 等旧键均保留；旧秒值迁移成毫秒，同时写回秒键。不要为了签名冲突直接卸载，卸载会删除旧选择。
2. GitHub Actions 默认 debug keystore 在新 runner 上可能不同。若你保留了旧构建签名密钥，可将其 Base64 放入仓库 secret `TIMEBANK_DEBUG_KEYSTORE_BASE64`，工作流会恢复到 `~/.android/debug.keystore`。必须是原来的密钥；任意新密钥无法覆盖旧 APK。没有旧密钥时，这个源码无法恢复旧签名。
3. 开启/重新开关时间银行无障碍；系统提示“受限设置”时，在应用信息里允许受限设置后再开。升级新增窗口读取能力，建议重新开关一次。
4. 首页允许精确耗尽提醒（闹钟和提醒），允许通知。
5. 首页确认“已开启 + 已连接 + 后台服务已启动 + 精确闹钟允许”。Usage Access 已移除，不再需要。
6. HyperOS 若限制后台运行：允许后台自启动、省电策略设为无限制。设备具体入口可能不同。不要把“通知存在”当作成功判据。

## 第一轮实机验证（全屏，不使用时间银行分屏/小窗）

1. 自由笔记选学习，Bilibili/小红书选娱乐，清零。打开 Bilibili，应回桌面；再开两次，仍应回桌面；时间银行应能正常打开。
2. 自由笔记全屏约 60 秒，再回时间银行，余额应约 +60 秒（切换操作允许少量误差）。复制诊断应有 notes 的进入记录和 `BOOK +... sec`。
3. 再清零，学习约 37 秒后直接打开 Bilibili，保持不切应用。应在当前余额耗尽时自动回桌面，不需要再打开时间银行。
4. 学习约 10 秒，熄屏约 60 秒，解锁后再学约 10 秒。总赚取约 20 秒，不应约 80 秒。娱乐也做一次相同测试。
5. 学习中弹出键盘继续输入；拉下通知栏停留 10 秒再收起；打开设置 10 秒。键盘应不抢走归属，系统面板和未分类设置不应算学习时间。
6. 分屏测试只计 active/focused 的一个窗口，不累计两个同时可见 App。画中画仍显示内容不等于拥有焦点，这不是防绕过/家长控制软件。
7. 04:00 前后不关闭应用以及关闭进程隔天重开各测一次，确认三项清零、分类不变。手动调整系统时间测试会触发“丢弃未结算区间”，这是保护机制。
8. 杀进程再打开，确认无巨额增减，并检查 `PROCESS start`。进程断开期间没有可靠使用记录，不补记。

失败时立即返回首页，点“复制诊断信息”，附测试步骤和大致时间。最近 50 条日志跨进程保留，仅存本地包名/状态/时间，不采集页面正文。

判断线索：
- 设置已开但 connected=false：无障碍没有实际绑定。
- 事件时间长期不变：系统没有交付监听事件。
- raw 包正确、计时包为空且 root=null：窗口读取不可用，不能继续猜包名。
- BOOK 数值正确而 HOME=false：拦截全局动作失败。
- DEGRADED / ALARM denied：精确提醒权限问题。
- DEADLINE 时间晚于预期：继续排查 ROM 调度，不能用成功编译证明实机可靠。

## 构建

仓库根目录上传 `TimeBank-Android-v0.4-source.zip`，再创建 `.github/workflows/build-apk.yml`，内容使用本 ZIP 同路径的 YAML。
GitHub 不会自动执行 ZIP 内的 workflow；必须在仓库单独建该文件。
该工作流解压到 `source/TimeBank-Android-v0.4`，执行：

```sh
gradle --no-daemon :app:testDebugUnitTest :app:assembleDebug
```

下载 artifact `TimeBank-v0.4-debug`，解压后是 `app-debug.apk`。
本地可选检查：`gradle :app:lintDebug`。验证结果见 `VALIDATION.md`。

## Android 官方依据

- [交互窗口读取能力与 getWindows](https://developer.android.com/reference/android/accessibilityservice/AccessibilityService#getWindows())
- [精确闹钟与用户特殊访问](https://developer.android.com/develop/background-work/services/alarms)
- [specialUse 前台服务权限与 subtype](https://developer.android.com/develop/background-work/services/fgs/service-types#special-use)
