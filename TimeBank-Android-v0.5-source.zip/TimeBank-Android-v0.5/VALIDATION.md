# TimeBank 0.5.0 验证记录

使用 Java 17、Gradle 8.13、Android SDK 36、build-tools 36.0.0，在全新项目输出目录实际执行：

```
gradle --no-daemon :app:testDebugUnitTest :app:assembleDebug :app:lintDebug
BUILD SUCCESSFUL in 7m 46s
52 actionable tasks: 52 executed
```

- 实际生成 app-debug.apk。
- APK 清单核验：com.timebank.app，versionCode=5，versionName=0.5.0，minSdk=26，targetSdk=36，compileSdk=36。
- 27 项单元测试通过，0 失败、0 错误、0 跳过。
- 其中 14 项测试覆盖新的前台事件推断，包括空窗口/空根节点、自由笔记赚 37 秒后娱乐耗尽、重复空查询不清状态、键盘/Toast/音量面板过滤、系统面板移除、桌面后再次打开娱乐应用、熄屏/断连清空旧证据、自身焦点、未知应用窗口。
- 其余 13 项测试覆盖账本区间、余额下限、04:00 重置、毫秒余量、时钟跳变和夏令时。
- Lint：0 errors, 3 warnings。分别是缺少显式应用图标和两项 KTX 写法建议。
- 对编译后的 MainActivity 字节码进行了检查，onResume 和 onWindowFocusChanged 均包含 ownFocused 调用。

## 实机边界

尚未在 Xiaomi 2405CRPFDC / SDK 36 实机运行。上述结果不能证明该 ROM 会持续交付外部应用事件，也不能证明 HOME 和精确闹钟没有厂商限制。
本轮确认修复的是“窗口不可用时拒绝有效事件”的代码路径，并让下一次诊断保留实际收到的事件证据。反复无障碍断连的原因尚未确定。
