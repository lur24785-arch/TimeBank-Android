package com.timebank.app

import android.accessibilityservice.AccessibilityService
import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityWindowInfo
import android.view.inputmethod.InputMethodManager
import androidx.core.content.ContextCompat

class TimeBankAccessibilityService : AccessibilityService(), ForegroundProbe {
    private var registered = false
    private var connected = false
    private val evidence = ForegroundEvidence()
    private val instance = Integer.toHexString(System.identityHashCode(this))
    private var windowSummary = "unknown"
    private val handler = Handler(Looper.getMainLooper())
    private var retry: Runnable? = null
    private var lastStart = -30_000L
    private var eventCount = 0L
    private var homeGeneration = -1L
    private var homeAttempts = 0
    private var imePackages = emptySet<String>()
    private val appCache = mutableMapOf<String, Boolean>()
    private val engine get() = bankEngine
    private fun screenUsable() = getSystemService(PowerManager::class.java).isInteractive &&
        !getSystemService(KeyguardManager::class.java).isKeyguardLocked
    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                Intent.ACTION_SCREEN_OFF -> {
                    evidence.clear("screen-off")
                    engine.observe(null, "screen-off", "SCREEN", false)
                }
                Intent.ACTION_TIME_CHANGED, Intent.ACTION_TIMEZONE_CHANGED ->
                    engine.refresh("CLOCK broadcast", discard = true)
                Intent.ACTION_INPUT_METHOD_CHANGED -> refreshIme()
                else -> engine.refresh("SCREEN / permission ${intent.action}")
            }
        }
    }
    override fun onCreate() {
        super.onCreate()
        engine.note("ACCESS onCreate instance=$instance")
    }
    override fun onServiceConnected() {
        super.onServiceConnected()
        connected = true
        evidence.clear("connected-awaiting-event")
        refreshIme()
        // Event types/flags are in XML. Reapplying serviceInfo on every bind is unnecessary.
        val info = serviceInfo
        engine.note("ACCESS onServiceConnected instance=$instance capabilities=${info.capabilities} " +
            "flags=${info.flags} types=${info.eventTypes} filters=${info.packageNames?.joinToString() ?: "all"}")
        if (!registered) {
            val filter = IntentFilter().apply {
                addAction(Intent.ACTION_SCREEN_OFF); addAction(Intent.ACTION_SCREEN_ON)
                addAction(Intent.ACTION_USER_PRESENT); addAction(Intent.ACTION_TIME_CHANGED)
                addAction(Intent.ACTION_TIMEZONE_CHANGED); addAction(Intent.ACTION_INPUT_METHOD_CHANGED)
                if (Build.VERSION.SDK_INT >= 31) addAction(android.app.AlarmManager.ACTION_SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED)
            }
            ContextCompat.registerReceiver(this, screenReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
            registered = true
        }
        engine.attach(this)
        ensureMonitor()
    }
    private fun refreshIme() {
        imePackages = getSystemService(InputMethodManager::class.java).inputMethodList.map { it.packageName }.toSet()
    }
    private fun ensureMonitor() {
        val now = SystemClock.elapsedRealtime()
        if (!engine.ui.value.monitoring && now - lastStart >= 30_000) {
            lastStart = now; MonitoringService.start(this)
        }
    }
    private fun kind(pkg: String?): AppKind {
        if (pkg in imePackages) return AppKind.IME
        if (pkg == "com.android.systemui" || pkg == "android") return AppKind.SYSTEM
        if (pkg == null) return AppKind.UNKNOWN
        val isApp = pkg == packageName || appCache.getOrPut(pkg) {
            packageManager.getLaunchIntentForPackage(pkg) != null ||
                packageManager.resolveActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0)
                    ?.activityInfo?.packageName == pkg
        }
        return if (isApp) AppKind.APP else AppKind.UNKNOWN
    }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!connected || event == null) return
        eventCount++
        ensureMonitor()
        val raw = event.packageName?.toString()
        val cls = event.className?.toString() ?: "—"
        val signal = when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> Signal.WINDOW
            AccessibilityEvent.TYPE_VIEW_FOCUSED -> Signal.FOCUS
            AccessibilityEvent.TYPE_VIEW_CLICKED -> Signal.CLICK
            else -> Signal.OTHER
        }
        if (Build.VERSION.SDK_INT >= 28 && event.eventType == AccessibilityEvent.TYPE_WINDOWS_CHANGED &&
            event.windowChanges and AccessibilityEvent.WINDOWS_CHANGE_REMOVED != 0) evidence.removed(event.windowId)
        val decision = if (screenUsable()) evidence.event(raw, kind(raw), signal, cls, event.windowId)
            else { evidence.clear("screen-off-or-locked"); "pause:screen" }
        val resolved = foreground()
        val type = AccessibilityEvent.eventTypeToString(event.eventType)
        val lag = (SystemClock.uptimeMillis() - event.eventTime).coerceAtLeast(0)
        engine.observe(resolved, raw ?: "—", type, windows = windowSummary,
            detail = "class=$cls id=${event.windowId} $decision source=${evidence.source} lagMs=$lag instance=$instance")
        // A bounded recheck after a transition; an unavailable root never wipes event evidence.
        if (signal == Signal.WINDOW && retry == null) {
            retry = Runnable {
                retry = null
                if (connected) engine.observe(foreground(), "recheck", "WINDOW_RECHECK", false,
                    windowSummary, "source=${evidence.source}")
            }
            handler.postDelayed(retry!!, 150)
        }
    }
    override fun foreground(): String? {
        if (!connected) { windowSummary = "disconnected"; return null }
        if (!screenUsable()) {
            evidence.clear("screen-off-or-locked")
            windowSummary = "screen-off / keyguard"; return null
        }
        try {
            val list = windows
            windowSummary = "windows=${list.size}; " + list.joinToString("; ") {
                "id=${it.id} type=${it.type} focus=${it.isFocused} active=${it.isActive}"
            }
            val candidates = list.filter { (it.isActive || it.isFocused) &&
                it.type != AccessibilityWindowInfo.TYPE_INPUT_METHOD &&
                it.type != AccessibilityWindowInfo.TYPE_ACCESSIBILITY_OVERLAY }
            val selected = candidates.firstOrNull { it.isActive } ?: candidates.firstOrNull { it.isFocused }
            if (selected != null && selected.type != AccessibilityWindowInfo.TYPE_APPLICATION) {
                evidence.root(true, null)
            } else {
                val root = selected?.root ?: rootInActiveWindow
                if (root == null) {
                    windowSummary += " root=null; EVENT FALLBACK"
                    evidence.root(false, null)
                } else {
                    try {
                        val pkg = root.packageName?.toString()
                        when {
                            pkg == null -> evidence.root(false, null)
                            pkg in imePackages -> Unit
                            pkg == "com.android.systemui" || pkg == "android" -> evidence.root(true, null)
                            else -> evidence.root(true, pkg)
                        }
                    } finally { @Suppress("DEPRECATION") root.recycle() }
                }
            }
        } catch (e: RuntimeException) {
            windowSummary = "probe error ${e.javaClass.simpleName}; EVENT FALLBACK"
        }
        windowSummary += "; source=${evidence.source}; inferred=${evidence.current}"
        return evidence.current
    }
    override fun ownForeground() { evidence.own(packageName) }
    override fun description(): String = "$windowSummary; localEvents=$eventCount; instance=$instance"
    override fun canAttemptHome(): Boolean = homeGeneration != evidence.generation || homeAttempts < 2
    override fun goHome(): Boolean {
        if (!connected || !screenUsable()) return false
        if (homeGeneration != evidence.generation) { homeGeneration = evidence.generation; homeAttempts = 0 }
        // No infinite HOME loop if the ROM accepts HOME but sends no launcher event.
        if (homeAttempts >= 2) return false
        homeAttempts++
        return performGlobalAction(GLOBAL_ACTION_HOME)
    }
    override fun onInterrupt() { engine.note("ACCESS onInterrupt instance=$instance") }
    override fun onUnbind(intent: Intent?): Boolean {
        disconnect("onUnbind")
        return super.onUnbind(intent)
    }
    private fun disconnect(reason: String) {
        engine.note("ACCESS $reason instance=$instance events=$eventCount wasConnected=$connected")
        if (connected) {
            connected = false; evidence.clear("disconnected")
            retry?.let { handler.removeCallbacks(it) }; retry = null
            engine.detach(this)
        }
        if (registered) { unregisterReceiver(screenReceiver); registered = false }
    }
    override fun onDestroy() { disconnect("onDestroy"); super.onDestroy() }
}
