package com.timebank.app

/** Pure, testable fallback. Absence of roots is UNKNOWN, not evidence of an idle screen. */
enum class AppKind { APP, IME, SYSTEM, UNKNOWN }
enum class Signal { WINDOW, FOCUS, CLICK, OTHER }
class ForegroundEvidence {
    var current: String? = null
        private set
    var source: String = "none"
        private set
    var generation: Long = 0
        private set
    private var window = -1
    private var underlying: Pair<String?, Int>? = null
    private var overlay = -1

    fun clear(reason: String) {
        current = null; window = -1; underlying = null; overlay = -1
        source = reason; generation++
    }
    fun own(pkg: String) {
        current = pkg; window = -1; underlying = null; overlay = -1
        source = "own-focus"; generation++
    }
    fun root(available: Boolean, pkg: String?) {
        if (!available) return // Crucial regression: preserve accepted event evidence.
        if (pkg != current) { generation++; window = -1; underlying = null; overlay = -1 }
        current = pkg
        if (pkg == null) { window = -1; underlying = null; overlay = -1 }
        source = if (pkg == null) "system-window" else "window-root"
    }
    fun event(pkg: String?, kind: AppKind, signal: Signal, className: String, id: Int): String {
        if (pkg.isNullOrBlank()) return "ignore:no-package"
        if (signal == Signal.OTHER) return "ignore:not-foreground-signal"
        if (className.contains("Toast", ignoreCase = true)) return "ignore:toast"
        if (kind == AppKind.IME) return "ignore:keyboard"
        if (kind == AppKind.SYSTEM && className.contains("Volume", ignoreCase = true)) return "ignore:volume"
        if (kind == AppKind.APP) {
            current = pkg; window = id; underlying = null; overlay = -1
            source = "event-inferred"; generation++
            return "accept:app-event"
        }
        if (signal == Signal.WINDOW) {
            if (overlay == -1) underlying = current to window
            overlay = id; current = null; source = "system-event"; generation++
            return "pause:system-or-unknown"
        }
        return "ignore:non-app-interaction"
    }
    fun removed(id: Int) {
        if (id < 0) return
        if (id == overlay) {
            current = underlying?.first; window = underlying?.second ?: -1
            underlying = null; overlay = -1; source = "overlay-removed-event"; generation++
        } else if (id == window) {
            clear("application-window-removed")
        }
    }
}
