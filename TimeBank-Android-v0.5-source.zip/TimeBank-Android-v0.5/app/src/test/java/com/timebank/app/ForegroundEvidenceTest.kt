package com.timebank.app

import org.junit.Assert.*
import org.junit.Test
import java.time.ZoneId
import java.time.ZonedDateTime

class ForegroundEvidenceTest {
    private val notes = "com.freenotes.freenotes"
    private val video = "com.workshop.virtuallover"
    private val own = "com.timebank.app"
    private fun noteEvent(e: ForegroundEvidence) = e.event(notes, AppKind.APP, Signal.WINDOW, "MainActivity", 17)

    @Test fun suppliedFailureEmptyWindowsAndNullRootStillResolveNotes() {
        val e = ForegroundEvidence()
        e.root(false, null)
        assertNull(e.current)
        assertEquals("accept:app-event", noteEvent(e))
        e.root(false, null)
        assertEquals(notes, e.current)
        assertEquals("event-inferred", e.source)
    }
    @Test fun repeatedRootFailureDuringDeadlineDoesNotClearEntertainment() {
        val e = ForegroundEvidence()
        e.event(video, AppKind.APP, Signal.WINDOW, "MainActivity", 18)
        repeat(5) { e.root(false, null) }
        assertEquals(video, e.current)
    }
    @Test fun emptyProbeTransitionCreditsNotesAndExhausts37Seconds() {
        val e = ForegroundEvidence()
        val zone = ZoneId.of("Asia/Shanghai")
        val w = ZonedDateTime.parse("2026-09-21T10:00:00+08:00[Asia/Shanghai]").toInstant().toEpochMilli()
        noteEvent(e); e.root(false, null)
        val role = if (e.current == notes) Role.EARNING else Role.IDLE
        val earned = Ledger.settle(Bank("2026-09-21"), role, 0, w, 37000, w + 37000, zone).bank
        assertEquals(37000L, earned.balanceMs)
        e.event(video, AppKind.APP, Signal.WINDOW, "MainActivity", 18); e.root(false, null)
        val spendRole = if (e.current == video) Role.SPENDING else Role.IDLE
        val spent = Ledger.settle(earned, spendRole, 37000, w + 37000, 74000, w + 74000, zone).bank
        assertEquals(0L, spent.balanceMs); assertEquals(37000L, spent.spentMs)
    }
    @Test fun keyboardAndToastDoNotReplaceForeground() {
        val e = ForegroundEvidence(); noteEvent(e)
        e.event("ime", AppKind.IME, Signal.WINDOW, "InputMethod", 99)
        e.event("com.android.systemui", AppKind.SYSTEM, Signal.WINDOW, "android.widget.Toast", 98)
        assertEquals(notes, e.current)
    }
    @Test fun volumeDoesNotEraseEvidence() {
        val e = ForegroundEvidence(); noteEvent(e)
        e.event("com.android.systemui", AppKind.SYSTEM, Signal.WINDOW, "VolumeDialogImpl", 98)
        assertEquals(notes, e.current)
    }
    @Test fun notificationPanelPausesAndItsRemovalResumes() {
        val e = ForegroundEvidence(); noteEvent(e)
        e.event("com.android.systemui", AppKind.SYSTEM, Signal.WINDOW, "NotificationShadeWindowView", 99)
        e.root(false, null); assertNull(e.current)
        e.removed(99); assertEquals(notes, e.current)
    }
    @Test fun unrelatedWindowRemovalDoesNotRestoreWrongApp() {
        val e = ForegroundEvidence(); noteEvent(e)
        e.event("com.android.systemui", AppKind.SYSTEM, Signal.WINDOW, "NotificationShade", 99)
        e.event(video, AppKind.APP, Signal.WINDOW, "VideoActivity", 18)
        e.removed(99); assertEquals(video, e.current)
    }
    @Test fun launcherThenSameEntertainmentAllowsFreshEnforcement() {
        val e = ForegroundEvidence()
        e.event(video, AppKind.APP, Signal.WINDOW, "Activity", 18)
        val first = e.generation
        e.event("com.miui.home", AppKind.APP, Signal.WINDOW, "Launcher", 19)
        assertEquals("com.miui.home", e.current)
        e.event(video, AppKind.APP, Signal.WINDOW, "Activity", 18)
        assertEquals(video, e.current); assertTrue(e.generation > first)
    }
    @Test fun disconnectAndScreenOffCannotRestoreOldEvidence() {
        val e = ForegroundEvidence(); noteEvent(e)
        e.clear("screen-off"); e.root(false, null); assertNull(e.current)
        noteEvent(e); e.clear("disconnected"); e.root(false, null); assertNull(e.current)
    }
    @Test fun ownFocusStopsAccountingEvenWithNoAccessibilityRoot() {
        val e = ForegroundEvidence(); noteEvent(e)
        e.own(own); e.root(false, null); assertEquals(own, e.current)
    }
    @Test fun rootEvidenceOverridesEventInferenceWhenAvailable() {
        val e = ForegroundEvidence(); noteEvent(e)
        e.root(true, video); assertEquals(video, e.current)
        e.root(true, null); assertNull(e.current)
    }
    @Test fun nonForegroundSignalsCannotSwitchApps() {
        val e = ForegroundEvidence(); noteEvent(e)
        e.event(video, AppKind.APP, Signal.OTHER, "TextView", 18)
        assertEquals(notes, e.current)
    }
    @Test fun interactionSupportsFocusChangesWithoutRoots() {
        val e = ForegroundEvidence(); noteEvent(e)
        e.event(video, AppKind.APP, Signal.CLICK, "Button", 18)
        assertEquals(video, e.current)
    }
    @Test fun unknownWindowPausesInsteadOfKeepingStaleLearningApp() {
        val e = ForegroundEvidence(); noteEvent(e)
        e.event("system.permission", AppKind.UNKNOWN, Signal.WINDOW, "PermissionDialog", 98)
        assertNull(e.current)
    }
}
