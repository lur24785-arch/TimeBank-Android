# TimeBank 0.5.0 — 针对 Xiaomi SDK 36 的空窗口诊断修复

包名 `com.timebank.app`；versionCode 5；versionName 0.5.0；minSdk 26；target/compileSdk 36。

## 本次实机证据与结论

用户的 v0.4 日志显示 `accessEnabled=true connected=true monitoring=true exactAllowed=true`，但 `current=null state=idle`，窗口诊断为 `no interactive windows; root fallback`，账本始终没有记账。

可以确认的代码缺陷：

1. v0.4 没拿到可用窗口包名就返回 null。接收到的 `event.packageName` 只用于诊断，没有参与兜底识别。因此“窗口信息不可用”被误当成“没有正在使用的应用”。
2. `null → null` 提前返回，原始事件也不写日志。因此原日志不能证明自由笔记的事件有没有送达。
3. 初始化等 DataStore 完成后重设锚点，而排队事件的时间可能更早；连接命令又在执行时采样。这可以制造启动时的负时间差告警。

不能由该日志确定：为什么窗口读取失败、为什么发生多次服务断连、系统是否持续发送自由笔记事件。新版本不把这些未知原因说成已查明。

## v0.5 的具体改动

- 区分“已知系统窗口/锁屏/熄屏”（应暂停）和“没有窗口信息”（允许用已接受的事件推断）。
- 对可启动应用、TimeBank 自己及默认桌面的窗口状态/焦点/点击事件进行筛选，作为当前前台应用的后备证据。
- 输入法、Toast、已识别的音量面板不覆盖普通应用；未识别应用的窗口状态变化保守暂停；非前台类事件不切换包名。
- 能读到实际窗口时使用窗口信息；读不到时标记 `EVENT FALLBACK` / `event-inferred`，不会被周期检查再次清空。
- 屏幕关闭、无障碍断连都清除推断状态；不持久化正在运行的前台时间戳。系统面板的匹配窗口移除事件可恢复之前的应用；普通应用窗口移除会清除该窗口的推断。
- TimeBank 自身的活动恢复/焦点回调也提供停止计时的信号，避免仅因无障碍窗口不可读而继续把 TimeBank 的使用算到前一个应用。
- 移除连接时重复写 serviceInfo。监听类型与窗口权限保留在 XML。此改动减少不必要的配置更新，不代表已经证明它是断连原因。
- 生命周期日志包含实例标识、onCreate / onServiceConnected / onUnbind / onDestroy、capabilities、flags、监听类型、事件数量。一次解绑/销毁只结算一次断连。
- 原始事件在提前返回之前记录，包括类型、包、类名、窗口 ID、采用/忽略原因、交付延迟。诊断另保留最近非 TimeBank 的已接受应用事件，避免返回首页后只剩自己的包名。
- 所有记账命令在提交时采样时间，初始化不再把时间锚点移到已排队事件之后。
- HOME 仍以当前证据核验目标；同一份证据最多尝试两次，防止无桌面事件时无限 HOME。新前台事件允许再次拦截同一个娱乐应用。

## 保留的规则

- 学习/娱乐 1:1，毫秒级余额与统计，娱乐余额不低于零；TimeBank、桌面及未分类应用不计时。
- 基于 elapsedRealtime 的区间记账；不用每秒回调次数计算使用时长。
- 娱乐余额耗尽使用系统一次性精确闹钟，Handler 作备份。精确提醒权限未开时明确显示降级。
- 每日本地 04:00 重置余额和今日统计，保留分类；关闭进程过日界线后启动仍重置。
- 60 秒 checkpoint 仅用于减少进程意外死亡时的未保存损失。进程死亡期间不补算未知使用时间。
- DataStore 文件名、旧分类键和余额迁移逻辑保持兼容。

## 本次最短实测

1. 覆盖安装后确认首页版本 0.5.0，无障碍已连接、后台服务运行、精确闹钟允许。
2. 学习仍选择自由笔记；清零后打开自由笔记全屏使用约 30 秒，回桌面，再回时间银行。应增加约 30 秒。
3. 展开日志或复制诊断，应能看到 `raw=com.freenotes.freenotes`、`accept:app-event`，在空窗口设备上通常还会有 `source=event-inferred`。最近外部应用事件应记录自由笔记。
4. 清零后打开你选中的娱乐应用，应回桌面；再次打开仍应拦截。再赚约 30 秒，在娱乐应用中保持不切换，检查自动耗尽。
5. 若第 2 步仍然为零，直接发整份诊断，不用重复切换所有权限。重点区分“根本没有外部应用事件”与“事件收到但被忽略”。

之后再测熄屏、通知栏、输入法、分屏焦点和跨日。分屏仅计当前操作的一个应用。

## 限制

事件兜底是推断，不是 Android 提供的实时前台真值。如果 ROM 丢失切换事件、对某应用隐藏事件或窗口信息，不能保证推断始终正确。尤其系统面板缺少打开/关闭事件时可能保守暂停，遗漏退出事件也可能产生归属偏差。诊断会显示采用的来源。

未在用户的 HyperOS 真机上执行测试。单元测试验证空窗口后的事件推断和账本逻辑，不能证明系统事件一定送达或 HOME 一定执行成功。画中画/悬浮窗不是严格防绕过的控制范围。

## 编译与升级

根目录上传 `TimeBank-Android-v0.5-source.zip`，单独创建/替换 `.github/workflows/build-apk.yml`（内容已放在本项目同路径，也会直接贴在交付回复中）。ZIP 内工作流不会自动被 GitHub 执行。

工作流使用 Java 17、Gradle 8.13、SDK 36、build-tools 36.0.0，`setup-android` 保持 `packages: platform-tools`，从 `source/TimeBank-Android-v0.5` 编译。

同签名覆盖安装可保留原分类和数据。可选 secret `TIMEBANK_DEBUG_KEYSTORE_BASE64` 必须是旧 debug 密钥的 Base64；未配置仍能编译，但新 runner 生成的签名可能不同。不要把任意新密钥当成旧签名；遇到签名冲突直接卸载会丢失数据。

实际编译验证见 `VALIDATION.md`。

## Android 官方接口依据

- [AccessibilityEvent：事件类型与包名](https://developer.android.com/reference/android/view/accessibility/AccessibilityEvent)
- [AccessibilityService：交互窗口获取](https://developer.android.com/reference/android/accessibilityservice/AccessibilityService#getWindows())
- [精确闹钟与权限](https://developer.android.com/develop/background-work/services/alarms)
