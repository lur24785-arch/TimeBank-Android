package com.timebank.app

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.timeBankDataStore by preferencesDataStore(name = "timebank_settings")

class TimeBankRepository(private val context: Context) {

    private object Keys {
        val EARN_APPS = stringSetPreferencesKey("earn_apps")
        val SPEND_APPS = stringSetPreferencesKey("spend_apps")
        val BALANCE_SECONDS = longPreferencesKey("balance_seconds")
        val EARNED_SECONDS = longPreferencesKey("earned_seconds")
        val SPENT_SECONDS = longPreferencesKey("spent_seconds")
    }

    val earnApps: Flow<Set<String>> =
        context.timeBankDataStore.data.map { it[Keys.EARN_APPS] ?: emptySet() }

    val spendApps: Flow<Set<String>> =
        context.timeBankDataStore.data.map { it[Keys.SPEND_APPS] ?: emptySet() }

    val balanceSeconds: Flow<Long> =
        context.timeBankDataStore.data.map { it[Keys.BALANCE_SECONDS] ?: 0L }

    val earnedSeconds: Flow<Long> =
        context.timeBankDataStore.data.map { it[Keys.EARNED_SECONDS] ?: 0L }

    val spentSeconds: Flow<Long> =
        context.timeBankDataStore.data.map { it[Keys.SPENT_SECONDS] ?: 0L }

    suspend fun setEarnApp(packageName: String, enabled: Boolean) {
        context.timeBankDataStore.edit { prefs ->
            val earn = (prefs[Keys.EARN_APPS] ?: emptySet()).toMutableSet()
            val spend = (prefs[Keys.SPEND_APPS] ?: emptySet()).toMutableSet()

            if (enabled) {
                earn += packageName
                spend -= packageName
            } else {
                earn -= packageName
            }

            prefs[Keys.EARN_APPS] = earn
            prefs[Keys.SPEND_APPS] = spend
        }
    }

    suspend fun setSpendApp(packageName: String, enabled: Boolean) {
        context.timeBankDataStore.edit { prefs ->
            val earn = (prefs[Keys.EARN_APPS] ?: emptySet()).toMutableSet()
            val spend = (prefs[Keys.SPEND_APPS] ?: emptySet()).toMutableSet()

            if (enabled) {
                spend += packageName
                earn -= packageName
            } else {
                spend -= packageName
            }

            prefs[Keys.EARN_APPS] = earn
            prefs[Keys.SPEND_APPS] = spend
        }
    }

    /** v0.1: fixed 1:1. One foreground second in an earn app == one credit second. */
    suspend fun earnOneSecond() {
        context.timeBankDataStore.edit { prefs ->
            val balance = prefs[Keys.BALANCE_SECONDS] ?: 0L
            val earned = prefs[Keys.EARNED_SECONDS] ?: 0L
            prefs[Keys.BALANCE_SECONDS] = balance + 1L
            prefs[Keys.EARNED_SECONDS] = earned + 1L
        }
    }

    /**
     * Returns true when one credit second was consumed.
     * Never lets the balance become negative.
     */
    suspend fun spendOneSecond(): Boolean {
        var consumed = false
        context.timeBankDataStore.edit { prefs ->
            val balance = prefs[Keys.BALANCE_SECONDS] ?: 0L
            if (balance > 0L) {
                val spent = prefs[Keys.SPENT_SECONDS] ?: 0L
                prefs[Keys.BALANCE_SECONDS] = balance - 1L
                prefs[Keys.SPENT_SECONDS] = spent + 1L
                consumed = true
            }
        }
        return consumed
    }

    suspend fun resetAllTime() {
        context.timeBankDataStore.edit { prefs ->
            prefs[Keys.BALANCE_SECONDS] = 0L
            prefs[Keys.EARNED_SECONDS] = 0L
            prefs[Keys.SPENT_SECONDS] = 0L
        }
    }
}
