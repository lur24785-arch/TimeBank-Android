package com.timebank.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.view.accessibility.AccessibilityEvent
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/*
 * Core blocking loop is adapted from Passlingo's AppBlockAccessibilityService:
 * https://github.com/Miszczykk/Passlingo
 *
 * Passlingo's original idea:
 *   - watch the foreground app
 *   - if it is locked and balance > 0, consume one second
 *   - otherwise show a lock screen
 *
 * TimeBank changes the earning side:
 *   - selected "earn apps" add one second per foreground second
 *   - selected "spend apps" consume one second per foreground second
 *
 * Passlingo is MIT-licensed. Full notice is in THIRD_PARTY_NOTICES.md.
 */
@SuppressLint("AccessibilityPolicy")
class TimeBankAccessibilityService : AccessibilityService() {

    private val job = SupervisorJob()
    private val scope = CoroutineScope(Dispatchers.IO + job)

    private lateinit var repository: TimeBankRepository

    @Volatile
    private var currentForegroundPackage: String? = null

    @Volatile
    private var isScreenOn: Boolean = true

    private var lastBlockedPackage: String? = null

    private val screenStateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            isScreenOn = intent.action == Intent.ACTION_SCREEN_ON
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()

        serviceInfo = AccessibilityServiceInfo().apply {
            eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            notificationTimeout = 100
            flags = 0
        }

        repository = TimeBankRepository(applicationContext)

        ContextCompat.registerReceiver(
            this,
            screenStateReceiver,
            IntentFilter().apply {
                addAction(Intent.ACTION_SCREEN_ON)
                addAction(Intent.ACTION_SCREEN_OFF)
            },
            ContextCompat.RECEIVER_NOT_EXPORTED
        )

        startAccountingLoop()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            event.packageName?.toString()?.let { pkg ->
                currentForegroundPackage = pkg
            }
        }
    }

    private fun startAccountingLoop() {
        scope.launch {
            while (isActive) {
                if (!isScreenOn) {
                    delay(1000)
                    continue
                }

                val currentPackage = currentForegroundPackage
                if (currentPackage == null || currentPackage == packageName) {
                    lastBlockedPackage = null
                    delay(1000)
                    continue
                }

                val earnApps = repository.earnApps.first()
                val spendApps = repository.spendApps.first()

                when {
                    currentPackage in earnApps -> {
                        repository.earnOneSecond()
                        lastBlockedPackage = null
                    }

                    currentPackage in spendApps -> {
                        val consumed = repository.spendOneSecond()
                        if (consumed) {
                            lastBlockedPackage = null
                        } else if (currentPackage != lastBlockedPackage) {
                            lastBlockedPackage = currentPackage
                            blockApplication(currentPackage)
                        }
                    }

                    else -> {
                        lastBlockedPackage = null
                    }
                }

                delay(1000)
            }
        }
    }

    private fun blockApplication(packageName: String) {
        startActivity(
            Intent(applicationContext, BlockActivity::class.java).apply {
                addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK or
                        Intent.FLAG_ACTIVITY_CLEAR_TASK or
                        Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS
                )
                putExtra(BlockActivity.EXTRA_BLOCKED_PACKAGE, packageName)
            }
        )
    }

    override fun onInterrupt() = Unit

    override fun onDestroy() {
        runCatching { unregisterReceiver(screenStateReceiver) }
        scope.cancel()
        super.onDestroy()
    }
}
