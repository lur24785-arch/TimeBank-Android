package com.timebank.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import java.util.Locale

class MainActivity : ComponentActivity() {

    private val accessibilityEnabledState = mutableStateOf(false)
    private val usageAccessState = mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        refreshPermissionState()
        maybeAskNotificationPermission()

        setContent {
            MaterialTheme {
                TimeBankApp(
                    accessibilityEnabled = accessibilityEnabledState.value,
                    usageAccessEnabled = usageAccessState.value,
                    onOpenAccessibility = { openAccessibilitySettings(this) },
                    onOpenUsageAccess = { openUsageAccessSettings(this) },
                    onStartMonitoring = {
                        if (hasUsageAccess(this)) {
                            MonitoringService.start(this)
                        }
                    }
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        refreshPermissionState()

        if (usageAccessState.value) {
            runCatching { MonitoringService.start(this) }
        }
    }

    private fun refreshPermissionState() {
        accessibilityEnabledState.value = isTimeBankAccessibilityEnabled(this)
        usageAccessState.value = hasUsageAccess(this)
    }

    private fun maybeAskNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                3001
            )
        }
    }
}

@Composable
private fun TimeBankApp(
    accessibilityEnabled: Boolean,
    usageAccessEnabled: Boolean,
    onOpenAccessibility: () -> Unit,
    onOpenUsageAccess: () -> Unit,
    onStartMonitoring: () -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val repository = remember { TimeBankRepository(context.applicationContext) }
    val scope = rememberCoroutineScope()

    val earnApps by repository.earnApps.collectAsState(initial = emptySet())
    val spendApps by repository.spendApps.collectAsState(initial = emptySet())
    val balanceSeconds by repository.balanceSeconds.collectAsState(initial = 0L)
    val earnedSeconds by repository.earnedSeconds.collectAsState(initial = 0L)
    val spentSeconds by repository.spentSeconds.collectAsState(initial = 0L)

    var apps by remember { mutableStateOf<List<InstalledApp>>(emptyList()) }
    var query by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        // Refresh the logical day even before the foreground service has had
        // a chance to start, so the UI never shows yesterday's balance.
        repository.ensureDailyReset()
        apps = loadLaunchableApps(context)
    }

    val filteredApps = remember(apps, query) {
        if (query.isBlank()) {
            apps
        } else {
            apps.filter {
                it.name.contains(query, ignoreCase = true) ||
                    it.packageName.contains(query, ignoreCase = true)
            }
        }
    }

    Surface(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Text(
                text = "时间银行",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "v0.2：后台计时版。固定 1:1。",
                style = MaterialTheme.typography.bodyMedium
            )

            Spacer(Modifier.height(12.dp))

            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("可用娱乐余额", style = MaterialTheme.typography.labelLarge)
                    Text(
                        text = formatSeconds(balanceSeconds),
                        style = MaterialTheme.typography.headlineLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(6.dp))
                    Text("累计赚取：${formatSeconds(earnedSeconds)}")
                    Text("累计消费：${formatSeconds(spentSeconds)}")

                    Spacer(Modifier.height(12.dp))

                    if (usageAccessEnabled) {
                        Text("✓ 使用情况访问权限已开启")
                    } else {
                        Text("⚠ 必须开启“使用情况访问权限”，后台才能知道当前是哪个 App。")
                        Spacer(Modifier.height(6.dp))
                        Button(onClick = onOpenUsageAccess) {
                            Text("去开启使用情况访问")
                        }
                    }

                    Spacer(Modifier.height(8.dp))

                    if (accessibilityEnabled) {
                        Text("✓ 无障碍服务已开启")
                    } else {
                        Text("⚠ 必须开启无障碍服务，余额归零后才能阻止娱乐 App。")
                        Spacer(Modifier.height(6.dp))
                        Button(onClick = onOpenAccessibility) {
                            Text("去开启无障碍服务")
                        }
                    }

                    Spacer(Modifier.height(8.dp))

                    Button(
                        onClick = onStartMonitoring,
                        enabled = usageAccessEnabled
                    ) {
                        Text("启动 / 重启后台计时")
                    }

                    Text(
                        text = "正常工作时，通知栏会有“时间银行正在后台计时”的常驻通知。",
                        style = MaterialTheme.typography.bodySmall
                    )

                    TextButton(
                        onClick = { scope.launch { repository.resetAllTime() } }
                    ) {
                        Text("清零余额和统计")
                    }
                }
            }

            Spacer(Modifier.height(12.dp))

            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("搜索应用") },
                singleLine = true
            )

            Spacer(Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                Text("学习（赚）     娱乐（花）")
            }

            HorizontalDivider()

            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(filteredApps, key = { it.packageName }) { app ->
                    AppRoleRow(
                        app = app,
                        earnChecked = app.packageName in earnApps,
                        spendChecked = app.packageName in spendApps,
                        onEarnChanged = { checked ->
                            scope.launch {
                                repository.setEarnApp(app.packageName, checked)
                            }
                        },
                        onSpendChanged = { checked ->
                            scope.launch {
                                repository.setSpendApp(app.packageName, checked)
                            }
                        }
                    )
                    HorizontalDivider()
                }
            }
        }
    }
}

@Composable
private fun AppRoleRow(
    app: InstalledApp,
    earnChecked: Boolean,
    spendChecked: Boolean,
    onEarnChanged: (Boolean) -> Unit,
    onSpendChanged: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = app.name,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Medium
            )
            Text(
                text = app.packageName,
                style = MaterialTheme.typography.bodySmall
            )
        }

        Checkbox(
            checked = earnChecked,
            onCheckedChange = onEarnChanged
        )
        Checkbox(
            checked = spendChecked,
            onCheckedChange = onSpendChanged
        )
    }
}

private fun formatSeconds(totalSeconds: Long): String {
    val safe = totalSeconds.coerceAtLeast(0L)
    val hours = safe / 3600
    val minutes = (safe % 3600) / 60
    val seconds = safe % 60

    return if (hours > 0L) {
        String.format(Locale.US, "%dh %02dm %02ds", hours, minutes, seconds)
    } else {
        String.format(Locale.US, "%02dm %02ds", minutes, seconds)
    }
}
