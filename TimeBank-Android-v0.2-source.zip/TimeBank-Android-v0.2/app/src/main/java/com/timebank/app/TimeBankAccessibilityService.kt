package com.timebank.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.view.accessibility.AccessibilityEvent
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/**
 * v0.2: Accessibility is only responsible for immediate enforcement.
 * Time accounting is handled by MonitoringService + UsageStats.
 */
@SuppressLint("AccessibilityPolicy")
class TimeBankAccessibilityService : AccessibilityService() {

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private lateinit var repository: TimeBankRepository

    private var lastBlockedPackage: String? = null

    private val blockRequestReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action != MonitoringService.ACTION_REQUEST_BLOCK) return
            val packageName = intent.getStringExtra(MonitoringService.EXTRA_PACKAGE) ?: return
            scope.launch {
                maybeBlock(packageName)
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()

        repository = TimeBankRepository(applicationContext)

        serviceInfo = AccessibilityServiceInfo().apply {
            eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            notificationTimeout = 100
            flags = 0
        }

        ContextCompat.registerReceiver(
            this,
            blockRequestReceiver,
            IntentFilter(MonitoringService.ACTION_REQUEST_BLOCK),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return

        val packageName = event.packageName?.toString() ?: return

        if (packageName == this.packageName) {
            lastBlockedPackage = null
            return
        }

        scope.launch {
            maybeBlock(packageName)
        }
    }

    private suspend fun maybeBlock(packageName: String) {
        val spendApps = repository.spendApps.first()
        if (packageName !in spendApps) {
            lastBlockedPackage = null
            return
        }

        val balance = repository.balanceSeconds.first()
        if (balance > 0L) {
            lastBlockedPackage = null
            return
        }

        if (lastBlockedPackage == packageName) return
        lastBlockedPackage = packageName
        blockApplication(packageName)
    }

    private fun blockApplication(packageName: String) {
        startActivity(
            Intent(applicationContext, BlockActivity::class.java).apply {
                addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK or
                        Intent.FLAG_ACTIVITY_CLEAR_TASK or
                        Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS
                )
                putExtra(BlockActivity.EXTRA_BLOCKED_PACKAGE, packageName)
            }
        )
    }

    override fun onInterrupt() = Unit

    override fun onDestroy() {
        runCatching { unregisterReceiver(blockRequestReceiver) }
        scope.cancel()
        super.onDestroy()
    }
}
