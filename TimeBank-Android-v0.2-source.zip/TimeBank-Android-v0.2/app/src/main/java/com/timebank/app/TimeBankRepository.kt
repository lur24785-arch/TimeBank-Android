package com.timebank.app

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.time.LocalDate
import java.time.LocalDateTime

private val Context.timeBankDataStore by preferencesDataStore(name = "timebank_settings")

class TimeBankRepository(private val context: Context) {

    companion object {
        /**
         * A TimeBank "day" changes at 04:00 local time instead of midnight.
         * 2026-09-21 03:30 therefore still belongs to the previous TimeBank day.
         */
        private const val DAY_BOUNDARY_HOUR = 4L
    }

    private object Keys {
        val EARN_APPS = stringSetPreferencesKey("earn_apps")
        val SPEND_APPS = stringSetPreferencesKey("spend_apps")
        val BALANCE_SECONDS = longPreferencesKey("balance_seconds")
        val EARNED_SECONDS = longPreferencesKey("earned_seconds")
        val SPENT_SECONDS = longPreferencesKey("spent_seconds")
        val ACTIVE_DAY = stringPreferencesKey("active_day")
    }

    val earnApps: Flow<Set<String>> =
        context.timeBankDataStore.data.map { it[Keys.EARN_APPS] ?: emptySet() }

    val spendApps: Flow<Set<String>> =
        context.timeBankDataStore.data.map { it[Keys.SPEND_APPS] ?: emptySet() }

    val balanceSeconds: Flow<Long> =
        context.timeBankDataStore.data.map { it[Keys.BALANCE_SECONDS] ?: 0L }

    val earnedSeconds: Flow<Long> =
        context.timeBankDataStore.data.map { it[Keys.EARNED_SECONDS] ?: 0L }

    val spentSeconds: Flow<Long> =
        context.timeBankDataStore.data.map { it[Keys.SPENT_SECONDS] ?: 0L }

    /**
     * Ensures balance and today's counters belong to the current TimeBank day.
     *
     * This is deliberately check-based rather than AlarmManager-based:
     * - if the foreground service is alive, its 1-second loop will reset soon after 04:00;
     * - if HyperOS kills the process overnight, the next app/service start will catch up.
     *
     * App role selections are never reset.
     */
    suspend fun ensureDailyReset(now: LocalDateTime = LocalDateTime.now()) {
        val currentDay = logicalDay(now).toString()

        context.timeBankDataStore.edit { prefs ->
            val savedDay = prefs[Keys.ACTIVE_DAY]

            if (savedDay == null) {
                // First install / first run: establish today's logical day without
                // destroying any balance the user may already have just earned.
                prefs[Keys.ACTIVE_DAY] = currentDay
                return@edit
            }

            if (savedDay != currentDay) {
                prefs[Keys.BALANCE_SECONDS] = 0L
                prefs[Keys.EARNED_SECONDS] = 0L
                prefs[Keys.SPENT_SECONDS] = 0L
                prefs[Keys.ACTIVE_DAY] = currentDay
            }
        }
    }

    private fun logicalDay(now: LocalDateTime): LocalDate =
        now.minusHours(DAY_BOUNDARY_HOUR).toLocalDate()

    suspend fun setEarnApp(packageName: String, enabled: Boolean) {
        context.timeBankDataStore.edit { prefs ->
            val earn = (prefs[Keys.EARN_APPS] ?: emptySet()).toMutableSet()
            val spend = (prefs[Keys.SPEND_APPS] ?: emptySet()).toMutableSet()

            if (enabled) {
                earn += packageName
                spend -= packageName
            } else {
                earn -= packageName
            }

            prefs[Keys.EARN_APPS] = earn
            prefs[Keys.SPEND_APPS] = spend
        }
    }

    suspend fun setSpendApp(packageName: String, enabled: Boolean) {
        context.timeBankDataStore.edit { prefs ->
            val earn = (prefs[Keys.EARN_APPS] ?: emptySet()).toMutableSet()
            val spend = (prefs[Keys.SPEND_APPS] ?: emptySet()).toMutableSet()

            if (enabled) {
                spend += packageName
                earn -= packageName
            } else {
                spend -= packageName
            }

            prefs[Keys.EARN_APPS] = earn
            prefs[Keys.SPEND_APPS] = spend
        }
    }

    suspend fun earnSeconds(seconds: Long) {
        if (seconds <= 0L) return
        context.timeBankDataStore.edit { prefs ->
            val balance = prefs[Keys.BALANCE_SECONDS] ?: 0L
            val earned = prefs[Keys.EARNED_SECONDS] ?: 0L
            prefs[Keys.BALANCE_SECONDS] = balance + seconds
            prefs[Keys.EARNED_SECONDS] = earned + seconds
        }
    }

    /**
     * Consumes up to [seconds] from the balance.
     * Returns the number of seconds actually consumed.
     */
    suspend fun spendSeconds(seconds: Long): Long {
        if (seconds <= 0L) return 0L
        var consumed = 0L
        context.timeBankDataStore.edit { prefs ->
            val balance = prefs[Keys.BALANCE_SECONDS] ?: 0L
            consumed = minOf(balance, seconds)
            if (consumed > 0L) {
                val spent = prefs[Keys.SPENT_SECONDS] ?: 0L
                prefs[Keys.BALANCE_SECONDS] = balance - consumed
                prefs[Keys.SPENT_SECONDS] = spent + consumed
            }
        }
        return consumed
    }

    /**
     * Manual reset button: clears today's numbers but keeps the current logical day
     * and all selected app roles.
     */
    suspend fun resetAllTime() {
        val currentDay = logicalDay(LocalDateTime.now()).toString()
        context.timeBankDataStore.edit { prefs ->
            prefs[Keys.BALANCE_SECONDS] = 0L
            prefs[Keys.EARNED_SECONDS] = 0L
            prefs[Keys.SPENT_SECONDS] = 0L
            prefs[Keys.ACTIVE_DAY] = currentDay
        }
    }
}
