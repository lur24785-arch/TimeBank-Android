package com.timebank.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Persistent background accounting service.
 *
 * Structure inspired by SelfLock's MIT-licensed MonitoringService:
 * https://github.com/EtashTyagi/SelfLock
 *
 * Unlike v0.1, accounting is not tied to AccessibilityService.
 */
class MonitoringService : Service() {

    companion object {
        const val CHANNEL_ID = "timebank_monitoring"
        const val NOTIFICATION_ID = 2001
        const val ACTION_REQUEST_BLOCK = "com.timebank.app.REQUEST_BLOCK"
        const val EXTRA_PACKAGE = "package_name"
        private const val POLL_INTERVAL_MS = 1000L
        private const val MAX_CREDIT_PER_TICK_SECONDS = 3L

        fun start(context: Context) {
            val intent = Intent(context, MonitoringService::class.java)
            androidx.core.content.ContextCompat.startForegroundService(context, intent)
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var pollingJob: Job? = null

    private lateinit var repository: TimeBankRepository
    private lateinit var usageStatsManager: UsageStatsManager
    private lateinit var powerManager: PowerManager

    private var lastPollRealtime = 0L
    private var lastKnownForeground: String? = null
    private var blockRequestedFor: String? = null

    override fun onCreate() {
        super.onCreate()
        repository = TimeBankRepository(applicationContext)
        usageStatsManager =
            getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = buildNotification()

        val foregroundType = if (Build.VERSION.SDK_INT >= 34) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        } else {
            0
        }

        ServiceCompat.startForeground(
            this,
            NOTIFICATION_ID,
            notification,
            foregroundType
        )

        startPolling()
        return START_STICKY
    }

    private fun startPolling() {
        if (pollingJob?.isActive == true) return

        lastPollRealtime = SystemClock.elapsedRealtime()

        pollingJob = scope.launch {
            while (isActive) {
                pollOnce()
                delay(POLL_INTERVAL_MS)
            }
        }
    }

    private suspend fun pollOnce() {
        // Daily boundary is 04:00 local time. This also catches up after a
        // process restart if HyperOS killed the service overnight.
        repository.ensureDailyReset()

        val nowRealtime = SystemClock.elapsedRealtime()

        if (!powerManager.isInteractive) {
            lastPollRealtime = nowRealtime
            lastKnownForeground = null
            blockRequestedFor = null
            return
        }

        val elapsedSeconds = ((nowRealtime - lastPollRealtime) / 1000L)
            .coerceIn(0L, MAX_CREDIT_PER_TICK_SECONDS)
        lastPollRealtime = nowRealtime

        val foregroundPackage = getForegroundPackage()
            ?: lastKnownForeground
            ?: return

        lastKnownForeground = foregroundPackage

        if (foregroundPackage == packageName) {
            blockRequestedFor = null
            return
        }

        val earnApps = repository.earnApps.first()
        val spendApps = repository.spendApps.first()

        when {
            foregroundPackage in earnApps -> {
                repository.earnSeconds(elapsedSeconds)
                blockRequestedFor = null
            }

            foregroundPackage in spendApps -> {
                val balanceBefore = repository.balanceSeconds.first()

                if (balanceBefore <= 0L) {
                    requestBlockOnce(foregroundPackage)
                    return
                }

                repository.spendSeconds(elapsedSeconds)

                val balanceAfter = repository.balanceSeconds.first()
                if (balanceAfter <= 0L) {
                    requestBlockOnce(foregroundPackage)
                } else {
                    blockRequestedFor = null
                }
            }

            else -> {
                blockRequestedFor = null
            }
        }
    }

    private fun requestBlockOnce(packageName: String) {
        if (blockRequestedFor == packageName) return
        blockRequestedFor = packageName

        sendBroadcast(
            Intent(ACTION_REQUEST_BLOCK).apply {
                setPackage(this@MonitoringService.packageName)
                putExtra(EXTRA_PACKAGE, packageName)
            }
        )
    }

    /**
     * Uses UsageEvents first, because it is better suited than aggregate stats
     * for determining the most recently resumed foreground app.
     */
    private fun getForegroundPackage(): String? {
        val end = System.currentTimeMillis()
        val start = end - 15_000L

        val events = usageStatsManager.queryEvents(start, end)
        val event = UsageEvents.Event()
        var latestPackage: String? = null
        var latestTimestamp = Long.MIN_VALUE

        while (events.hasNextEvent()) {
            events.getNextEvent(event)
            val isForeground = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                event.eventType == UsageEvents.Event.ACTIVITY_RESUMED
            } else {
                @Suppress("DEPRECATION")
                event.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND
            }

            if (isForeground && event.timeStamp >= latestTimestamp) {
                latestTimestamp = event.timeStamp
                latestPackage = event.packageName
            }
        }

        if (latestPackage != null) return latestPackage

        // Fallback for ROMs that expose sparse UsageEvents.
        return usageStatsManager
            .queryUsageStats(UsageStatsManager.INTERVAL_BEST, start, end)
            ?.maxByOrNull { it.lastTimeUsed }
            ?.packageName
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        pollingJob?.cancel()
        scope.cancel()
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText(getString(R.string.notification_text))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(pendingIntent)
            .build()
    }
}
