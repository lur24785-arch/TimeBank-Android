package com.timebank.app

import android.content.Context
import android.content.pm.PackageManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class InstalledApp(
    val name: String,
    val packageName: String
)

suspend fun loadLaunchableApps(context: Context): List<InstalledApp> =
    withContext(Dispatchers.IO) {
        val pm = context.packageManager
        val ownPackage = context.packageName

        pm.getInstalledApplications(PackageManager.GET_META_DATA)
            .asSequence()
            .filter { it.packageName != ownPackage }
            .filter { pm.getLaunchIntentForPackage(it.packageName) != null }
            .map {
                InstalledApp(
                    name = it.loadLabel(pm).toString(),
                    packageName = it.packageName
                )
            }
            .distinctBy { it.packageName }
            .sortedBy { it.name.lowercase() }
            .toList()
    }
